﻿<?php

/**
 * User class
 */
class User
{

  protected $db;
  
  
  public function __construct()
  {

    $this->db = DB::getInstance();
  
  }
  
  
  public function checkLogin() 
  {
    if( isset( $_REQUEST['username'] ) && isset( $_REQUEST['password'] ) ) {
    
      /**
       * To-do: 
       * 1. MAKE SAFE WITH password_verify http://php.net/manual/en/function.password-verify.php 
       */
      $user = $this->db->run( 'SELECT * FROM users WHERE active = 1 AND email = ?', [$_REQUEST['username']])->fetch();
      if( is_array( $user ) && $user['password'] == $_REQUEST['password'] ) {
        $_SESSION['user'] = $user;
        return true;
      }
      
    } elseif( isset( $_SESSION['user'] ) ) {
      
      //To-do: populate user-object with user-data from session, return true
        
    }
    
    
    //fallback, in case user-info is not submitted via loginform and not available in session
    return false;
    
  }  
  
  


}