﻿<?php

class DB
{
  protected static $instance;
  protected $pdo;
  
  
  /**
   * Setup PDO connection
   */
  protected function __construct() {
    
    $opt  = array(
      PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES   => FALSE,
    );
    
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHAR;
    $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $opt);  
  }
  
  
  /**
   * getInstance
   * 
   * makes sure only one instance of this class exists universally
   */
  public static function getInstance()
  {
    if (self::$instance === null)
    {
      self::$instance = new self;
    }
    return self::$instance;
  }
  
  
  /**
   * Call native PDO methods
   */
  public function __call($method, $args)
  {
    return call_user_func_array(array($this->pdo, $method), $args);
  }
  
  
  /**
   * Helps to run prepared statements smoothly
   */
  public function run($sql, $args = [])
  {
    if (!$args)
    {
       return $this->query($sql);
    }
    $stmt = $this->pdo->prepare($sql);
    $stmt->execute($args);
    return $stmt;
  }
}



