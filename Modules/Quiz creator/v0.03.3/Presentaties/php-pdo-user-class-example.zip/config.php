﻿<?php

/**
 * Config file
 * 
 * database settings
 * loads classes
 * starts session
 * usefull helper functions
 */

define( 'DB_HOST', 'localhost' );
define( 'DB_NAME', 'p7' );
define( 'DB_CHAR', 'utf8mb4' );
define( 'DB_USER', 'root' );
define( 'DB_PASS', '' );

session_start();

require_once 'includes/db.class.php';
require_once 'includes/user.class.php';



function preprint_r( $arr = [] ) {
  echo '<pre>';
  print_r( $arr );
  echo '</pre>';
}








