﻿<?php

/**
 * index.php
 */

require_once 'config.php';


$user = new User();
$logged_in = $user->checkLogin();


if( $logged_in ) {
  //display user menu  
  
  
} else {
  //display login form  
  
  
}





